--||Author:	Phuc Nguyen
--||Date:	22/9/2024
--||Feaure:	 nhu t�nh
--||Description:	You are missing in my heart

function useitem(nItemIndex)
	if (CheckRoom(6,9) == 1) then
		for i=189,192 do
		AddItem(2,0,i,0,0,0,5,0)
		end
		RemoveItem(nItemIndex,1)
		Msg2Player("Nh�n ���c 1 b� Nhu T�nh.") 
	else
		Talk(1,"",12266)
	end
end;
