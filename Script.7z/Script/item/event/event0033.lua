--Phuc Nguyen--
-- Source Vo Lam Truyen Ky
-- Copyright (C) 2024 Phuc Nguyen.
-- This program comes with NO WARRANTY; see LICENSE.txt for details.
-- You are free to redistribute it under certain conditions.

Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\nhanhotro.lua");
Include("\\script\\header\\monphaiheader.lua");

NOT_LEVEL = "<color=yellow>B¹n cÇn ph¶i ®¹t %d cÊp ®Ó nhËn th­ëng!"
ALREADY = "<color=yellow>B¹n ®· nhËn phÇn th­ëng nµy tr­íc ®©y råi."

function useitem(nItemIdx)
dofile("script/item/event/event0033.lua")
ActiveMPLB()
end
----------------------------------------==PhÇn***Th­ëng==------------------------------------------
   --------------------------------------------------------------------------------------------
function ActiveMPLB()
	Say2("<color=yellow>Xin mêi vÞ anh hïng lùa chän gãi phÇn th­ëng cña m×nh.",6,1,"",
        "NhËn th­ëng hç trî t©n thñ ./thuongtanthu",
        "NhËn th­ëng hµng ngµy ./thuongngay",
        "NhËn th­ëng chóc phóc ./chucphuc",
        "NhËn th­ëng th¨ng cÊp ./thuongthangcap",
	"KÕt thóc ®èi tho¹i ./no")
end
----------------------------------------==T©n***Thñ==------------------------------------------
   ----------------------------------------------------------------------------------------
function thuongtanthu()
	Say2("<color=yellow>Xin mêi vÞ anh hïng lùa chän gãi phÇn th­ëng cña m×nh.",6,1,"",
        "§¼ng cÊp d­íi 10 ./thuong10",
        "§¼ng cÊp d­íi 150 vµ ®· gia nhËp ph¸i. /thuong150",
	"KÕt thóc ®æi tho¹i/no")
end

function thuong10()
	if(GetLevel() > 10) then
		Talk(1, "", ALREADY)
	return end
	SetLevel(11);
end
function thuong150()
	local nSel = GetFactionNo()
	if(nSel < 0 or nSel > 9) then
		Talk(1, "", "<color=yellow>B¹n ch­a gia nhËp m«n ph¸i.")
	return end
	if(CheckRoom(6,9) == 0) then
		Talk(1, "", 12266)
	return end
	nSel = nSel + 1;
	local nValue = GetTask(TASK_TANTHU)
	if(GetNumber(nValue,1) > 0) then
		Talk(1, "", ALREADY)
	return end
	SetTask(TASK_TANTHU, SetNumber(nValue,1,1));
	local nIndex = ItemSetAdd(0,2,10,0,0,5,0);--than hanh phu
	if(nIndex > 0) then
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)--30 ngay
		AddItemID(nIndex)
        end
	nIndex = ItemSetAdd(0,2,9,0,0,5,0);--tho dia phu
	if(nIndex > 0) then
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)
		AddItemID(nIndex)
        end
	for i=1,12 do
		nIndex = ItemSetAdd(0,2,45,0,0,5,0);--tien thao lo
		if(nIndex > 0) then
			LockItem(nIndex)--khoa bao hiem vinh vien
			AddItemID(nIndex)
                end
	end
	nIndex = ItemSetAdd(0,0,10,6,10,0,0);--bontieu
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,5,56,0,0,5,0);--Tö M·ng
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,90,0,0,5,0);--§¹i Thµnh bk 90
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,91,0,0,5,0);--§¹i Thµnh bk 120
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(2,0,3474,0,0,0,8);--phiphong
		LockItem(nIndex)--khoa bao hiem vinh vien
                SetItemDate(nIndex,43200)
		AddItemID(nIndex)
	nIndex = ItemSetAdd(2,0,3208,0,0,0,8);--An
		LockItem(nIndex)--khoa bao hiem vinh vien
                SetItemDate(nIndex,43200)
		AddItemID(nIndex)
	nIndex = ItemSetAdd(2,0,3500,0,0,0,8);--Trang suc
		LockItem(nIndex)--khoa bao hiem vinh vien
                SetItemDate(nIndex,43200)
		AddItemID(nIndex)
	if(GetLevel() < 10) then
		Talk(1, "", "<color=yellow>B¹n luyÖn ®Õn cÊp 10 h·y quay l¹i nhËn.")
	return end
	SetLevel(151);
end

----------------------------------------==Hµng***Ngµy==------------------------------------------
   ----------------------------------------------------------------------------------------	
function thuongngay()
        local nValue = GetTask(TASK_RESET);
	local nUsed = GetNumber(nValue,11);
	if (nUsed >= 1) then
		Talk(1, "", "<color=yellow>H«m nay b¹n ®· nhËn quµ råi. Mai h·y tiÕp tôc!")
	return end
	if(CheckRoom(5,5) == 0) then
		Talk(1, "", "<color=yellow>Xin s¾p xÕp l¹i hµnh trang cÇn ®Ó trèng 5x5 «.")
	return end
        SetTask(TASK_RESET,SetNumber(nValue,11,nUsed+1))
		local nid = ItemSetAdd(0,5,32,0,0,5,0);--mauxu
		LockItem(nid);--khoa bao hiem vinh vien
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,30,0,0,5,3,0);--hat thien tue
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,30,0,0,5,3,0);--hat thien tue
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,3,34,0,0,5,2,0);--lenh bai phong lang ®«
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,3,27,0,0,5,2,0);--satthugian
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,3,27,0,0,5,2,0);--satthugian
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,3,27,0,0,5,2,0);--satthugian
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,2,45,0,0,5,3,0);--tien thao lo
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,2,45,0,0,5,3,0);--tien thao lo
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,2,45,0,0,5,3,0);--tien thao lo
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,29,0,0,5,3,0);--ve so
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,29,0,0,5,3,0);--ve so
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,29,0,0,5,3,0);--ve so
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,135,0,0,5,25,0);--ve so
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
                AddItem(0,2,2,0,0,5,10,0)--phuc duyen
	        Earn(500000);
	        AddRepute(100);
	        AddLeadExp(5000000)
end

----------------------------------------==Chóc***Phóc==------------------------------------------
   ----------------------------------------------------------------------------------------
function chucphuc()
 local nValue = GetTask(TASK_RESET);
	local nUsed = GetNumber(nValue,13);
	if (nUsed >= 5) then
		Talk(1, "", "<color=yellow>H«m nay b¹n ®· hÕt l­ît råi quµ råi. Mai h·y chóc phóc tiÕp!")
return end
	if(GetLevel() < 150) then
		Talk(1, "", "<color=yellow>§¼ng cÊp 150 míi cã thÓ chóc phóc.")
return end
        if (CheckRoom(2,2) == 0) then
	Talk(1,"","Xin s¾p xÕp hµnh trang 2x2 «!")
return end
        local nMoney = GetCash()
	if( nMoney < 500000) then
        Talk(1,"","<color=yellow>Chóc phóc cÇn tiªu hao 50 v¹n l­îng. Ng­¬i kh«ng ®em theo råi.")
return end
	Pay(500000)
	vatpham();
	AddOwnExp(5000000)
        SetTask(TASK_RESET,SetNumber(nValue,13,nUsed+1))
end
	
function vatpham()
local nRand = RANDOM(700);
	if(nRand == 500) then
		AddItem(0,4,RANDOM(72,79),0,0,5,0,0)
	elseif(nRand == 550) then
		AddItem(0,5,RANDOM(71,73),0,0,0,5,0)
	elseif(nRand == 560) then
		AddItem(0,5,1,0,0,5,0,0)
	elseif(nRand == 570) then
		AddItem(0,3,RANDOM(13,18),0,0,0,5,0)
	elseif(nRand == 510) then
	end
end

----------------------------------------==Th¨ng***CÊp==------------------------------------------
   ----------------------------------------------------------------------------------------
function thuongthangcap()
local nValue = GetTask(TASK_RESET);
	local nUsed = GetNumber(nValue,14);
	if (nUsed >= 1) then
		Talk(1, "", "<color=yellow>Mçi ngµy chØ ®­îc phÐp th¨ng cÊp 1 lÇn. Mai h·y ®Õn tiÕp!")
return end
	if(GetLevel() < 150) then
		Talk(1, "", "<color=yellow>§¼ng cÊp 151 míi cã thÓ nhËn th­ëng.")
return end
        local nMoney = GetCash()
	if( nMoney < 5000000) then
        Talk(1,"","<color=yellow>CÇn tiªu hao 500 v¹n c¸c h¹ kh«ng ®em theo ®ñ råi!")
return end
	local nHL1 = GetItemCount(32,5)
	local nHL2 = GetItemCount(33,5)
	local nHL3 = GetItemCount(34,5)
	local nHL4 = GetItemCount(35,5)
	local nHL5 = GetItemCount(36,5)
	local nTotal = nHL1 + nHL2 + nHL3 +nHL4 +nHL5
	if(nTotal < 5) then
		Talk(1,"","CÇn cã ®ñ <color=red>5 <color> <color=yellow>Hµnh HiÖp Kú <color> <color=red>1 + 2 + 3 + 4 + 5 <color> c¸c h¹ mang theo kh«ng ®ñ råi!")
	return end
	Pay(500000)
	AddOwnExp(2000000000)
        SetTask(TASK_RESET,SetNumber(nValue,14,nUsed+1))
        nTotal = 5;
		for i=1,3 do
			if(nTotal > 0 and nHL1 > 0) then
			DelItem(32,5)
			nTotal = nTotal - 1
			nHL1 = nHL1 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nHL2 > 0) then
			DelItem(33,5)
			nTotal = nTotal - 1
			nHL2 = nHL2 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nHL3 > 0) then
			DelItem(34,5)
			nTotal = nTotal - 1
			nHL3 = nHL3 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nHL4 > 0) then
			DelItem(35,5)
			nTotal = nTotal - 1
			nHL4 = nHL4 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nHL5 > 0) then
			DelItem(36,5)
			nTotal = nTotal - 1
			nHL5 = nHL5 - 1
                end
end
		Talk(1,"","<color=yellow> Chóc mõng c¸c h¹ ®· th¨ng cÊp thµnh c«ng!");
end

-------------------------------------------------------------------------------------------
function no()
end
-------------------------------------------------------------------------------------------
