--Phuc Nguyen--

Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\nhanhotro.lua");
Include("\\script\\header\\monphaiheader.lua");

NOT_LEVEL = "<color=yellow>B�n c�n ph�i ��t %d c�p �� nh�n th��ng!"
ALREADY = "<color=yellow>B�n �� nh�n ph�n th��ng n�y tr��c ��y r�i."

function useitem(nItemIdx)
dofile("script/item/event/event0036.lua")
ActiveMPLB()
end
----------------------------------------==Ph�n***Th��ng==------------------------------------------
   --------------------------------------------------------------------------------------------
function ActiveMPLB()
	Say2("<color=yellow>Xin m�i v� anh h�ng l�a ch�n g�i ph�n th��ng c�a m�nh.",6,1,"",
        "Nh�n th��ng h� tr� t�n th� ./thuongtanthu",
        "Nh�n th��ng h�ng ng�y ./thuongngay",
        "Nh�n th��ng ch�c ph�c ./chucphuc",
        "Nh�n th��ng th�ng c�p ./thuongthangcap",
	"K�t th�c ��i tho�i ./no")
end
----------------------------------------==T�n***Th�==------------------------------------------
   ----------------------------------------------------------------------------------------
function thuongtanthu()
	Say2("<color=yellow>Xin m�i v� anh h�ng l�a ch�n g�i ph�n th��ng c�a m�nh.",6,1,"",
        "��ng c�p d��i 10 ./thuong10",
        "��ng c�p d��i 150 v� �� gia nh�p ph�i. /thuong150",
	"K�t th�c ��i tho�i/no")
end

function thuong10()
	if(GetLevel() > 10) then
		Talk(1, "", ALREADY)
	return end
	SetLevel(11);
end
function thuong150()
	local nSel = GetFactionNo()
	if(nSel < 0 or nSel > 9) then
		Talk(1, "", "<color=yellow>B�n ch�a gia nh�p m�n ph�i.")
	return end
	if(CheckRoom(6,9) == 0) then
		Talk(1, "", 12266)
	return end
	nSel = nSel + 1;
	local nValue = GetTask(TASK_TANTHU)
	if(GetNumber(nValue,1) > 0) then
		Talk(1, "", ALREADY)
	return end
	SetTask(TASK_TANTHU, SetNumber(nValue,1,1));
	local nIndex = ItemSetAdd(0,2,10,0,0,5,0);--than hanh phu
	if(nIndex > 0) then
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)--30 ngay
		AddItemID(nIndex)
        end
	nIndex = ItemSetAdd(0,2,9,0,0,5,0);--tho dia phu
	if(nIndex > 0) then
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)
		AddItemID(nIndex)
        end
	for i=1,12 do
		nIndex = ItemSetAdd(0,2,45,0,0,5,0);--tien thao lo
		if(nIndex > 0) then
			LockItem(nIndex)--khoa bao hiem vinh vien
			AddItemID(nIndex)
                end
	end
	nIndex = ItemSetAdd(0,0,10,6,10,0,0);--bontieu
		LockItem(nIndex)--khoa bao hiem vinh vien
		SetItemDate(nIndex,43200)
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,5,56,0,0,5,0);--T� M�ng
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,90,0,0,5,0);--��i Th�nh bk 90
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(0,2,91,0,0,5,0);--��i Th�nh bk 120
		LockItem(nIndex)--khoa bao hiem vinh vien
		AddItemID(nIndex)
	nIndex = ItemSetAdd(2,0,3474,0,0,0,8);--phiphong
		LockItem(nIndex)--khoa bao hiem vinh vien
                SetItemDate(nIndex,43200)
		AddItemID(nIndex)
	nIndex = ItemSetAdd(2,0,3208,0,0,0,8);--An
		LockItem(nIndex)--khoa bao hiem vinh vien
                SetItemDate(nIndex,43200)
		AddItemID(nIndex)
	nIndex = ItemSetAdd(2,0,3500,0,0,0,8);--Trang suc
		LockItem(nIndex)--khoa bao hiem vinh vien
                SetItemDate(nIndex,43200)
		AddItemID(nIndex)
	if(GetLevel() < 10) then
		Talk(1, "", "<color=yellow>B�n luy�n ��n c�p 10 h�y quay l�i nh�n.")
	return end
	SetLevel(151);
end

----------------------------------------==H�ng***Ng�y==------------------------------------------
   ----------------------------------------------------------------------------------------	
function thuongngay()
        local nValue = GetTask(TASK_RESET);
	local nUsed = GetNumber(nValue,11);
	if (nUsed >= 1) then
		Talk(1, "", "<color=yellow>H�m nay b�n �� nh�n qu� r�i. Mai h�y ti�p t�c!")
	return end
	if(CheckRoom(5,5) == 0) then
		Talk(1, "", "<color=yellow>Xin s�p x�p l�i h�nh trang c�n �� tr�ng 5x5 �.")
	return end
        SetTask(TASK_RESET,SetNumber(nValue,11,nUsed+1))
		local nid = ItemSetAdd(0,5,32,0,0,5,0);--mauxu
		LockItem(nid);--khoa bao hiem vinh vien
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,30,0,0,5,3,0);--hat thien tue
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,30,0,0,5,3,0);--hat thien tue
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,3,34,0,0,5,2,0);--lenh bai phong lang ��
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,3,27,0,0,5,2,0);--satthugian
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,3,27,0,0,5,2,0);--satthugian
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,3,27,0,0,5,2,0);--satthugian
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,2,45,0,0,5,3,0);--tien thao lo
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,2,45,0,0,5,3,0);--tien thao lo
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,2,45,0,0,5,3,0);--tien thao lo
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,29,0,0,5,3,0);--ve so
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,29,0,0,5,3,0);--ve so
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,29,0,0,5,3,0);--ve so
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
		nid = ItemSetAdd(0,5,135,0,0,5,25,0);--ve so
		LockItem(nid);
		SetItemDate(nIndex,10800)
		AddItemID(nid);
                AddItem(0,2,2,0,0,5,10,0)--phuc duyen
	        Earn(500000);
	        AddRepute(100);
	        AddLeadExp(5000000)
end

----------------------------------------==Ch�c***Ph�c==------------------------------------------
   ----------------------------------------------------------------------------------------
function chucphuc()
 local nValue = GetTask(TASK_RESET);
	local nUsed = GetNumber(nValue,13);
	if (nUsed >= 5) then
		Talk(1, "", "<color=yellow>H�m nay b�n �� h�t l��t r�i qu� r�i. Mai h�y ch�c ph�c ti�p!")
return end
	if(GetLevel() < 150) then
		Talk(1, "", "<color=yellow>��ng c�p 150 m�i c� th� ch�c ph�c.")
return end
        if (CheckRoom(2,2) == 0) then
	Talk(1,"","Xin s�p x�p h�nh trang 2x2 �!")
return end
        local nMoney = GetCash()
	if( nMoney < 500000) then
        Talk(1,"","<color=yellow>Ch�c ph�c c�n ti�u hao 50 v�n l��ng. Ng��i kh�ng �em theo r�i.")
return end
	Pay(500000)
	vatpham();
	AddOwnExp(5000000)
        SetTask(TASK_RESET,SetNumber(nValue,13,nUsed+1))
end
	
function vatpham()
local nRand = RANDOM(700);
	if(nRand == 500) then
		AddItem(0,4,RANDOM(72,79),0,0,5,0,0)
	elseif(nRand == 550) then
		AddItem(0,5,RANDOM(71,73),0,0,0,5,0)
	elseif(nRand == 560) then
		AddItem(0,5,1,0,0,5,0,0)
	elseif(nRand == 570) then
		AddItem(0,3,RANDOM(13,18),0,0,0,5,0)
	elseif(nRand == 510) then
	end
end

----------------------------------------==Th�ng***C�p==------------------------------------------
   ----------------------------------------------------------------------------------------
function thuongthangcap()
local nValue = GetTask(TASK_RESET);
	local nUsed = GetNumber(nValue,14);
	if (nUsed >= 1) then
		Talk(1, "", "<color=yellow>M�i ng�y ch� ���c ph�p th�ng c�p 1 l�n. Mai h�y ��n ti�p!")
return end
	if(GetLevel() < 150) then
		Talk(1, "", "<color=yellow>��ng c�p 151 m�i c� th� nh�n th��ng.")
return end
        local nMoney = GetCash()
	if( nMoney < 5000000) then
        Talk(1,"","<color=yellow>C�n ti�u hao 500 v�n c�c h� kh�ng �em theo �� r�i!")
return end
	local nHL1 = GetItemCount(32,5)
	local nHL2 = GetItemCount(33,5)
	local nHL3 = GetItemCount(34,5)
	local nHL4 = GetItemCount(35,5)
	local nHL5 = GetItemCount(36,5)
	local nTotal = nHL1 + nHL2 + nHL3 +nHL4 +nHL5
	if(nTotal < 5) then
		Talk(1,"","C�n c� �� <color=red>5 <color> <color=yellow>H�nh Hi�p K� <color> <color=red>1 + 2 + 3 + 4 + 5 <color> c�c h� mang theo kh�ng �� r�i!")
	return end
	Pay(500000)
	AddOwnExp(2000000000)
        SetTask(TASK_RESET,SetNumber(nValue,14,nUsed+1))
        nTotal = 5;
		for i=1,3 do
			if(nTotal > 0 and nHL1 > 0) then
			DelItem(32,5)
			nTotal = nTotal - 1
			nHL1 = nHL1 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nHL2 > 0) then
			DelItem(33,5)
			nTotal = nTotal - 1
			nHL2 = nHL2 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nHL3 > 0) then
			DelItem(34,5)
			nTotal = nTotal - 1
			nHL3 = nHL3 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nHL4 > 0) then
			DelItem(35,5)
			nTotal = nTotal - 1
			nHL4 = nHL4 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nHL5 > 0) then
			DelItem(36,5)
			nTotal = nTotal - 1
			nHL5 = nHL5 - 1
                end
end
		Talk(1,"","<color=yellow> Ch�c m�ng c�c h� �� th�ng c�p th�nh c�ng!");
end

-------------------------------------------------------------------------------------------
function no()
end
-------------------------------------------------------------------------------------------
