
function main(sel)

	if(NewWorld(162,1692,3181) == 1) then	-- 	
	SetFightState(0)		-- 
	end
end;
