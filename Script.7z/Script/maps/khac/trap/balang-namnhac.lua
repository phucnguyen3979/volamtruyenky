
function main(sel)

	if(NewWorld(54, 1466,2982) == 1) then
	SetFightState(0)		--
	end
	
end;
