
function main(sel)

	NewWorld(122,1596,3214)		--	
	SetFightState(1)		--
end;
