
function main(sel)

	NewWorld(322,1581,3146)		
	SetFightState(1)
    AddWayPoint(201)

end;
