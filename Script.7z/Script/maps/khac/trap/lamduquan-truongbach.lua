
function main(sel)
	SetFightState(1)		--
	if(NewWorld(320, 1146,3130) == 1) then		--	
	AddWayPoint(197)
	end
end;
