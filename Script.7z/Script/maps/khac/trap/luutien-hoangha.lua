
function main(sel)

	NewWorld(122,1646,3199)		--	
	SetFightState(1)		--
    AddWayPoint(182)
end;
