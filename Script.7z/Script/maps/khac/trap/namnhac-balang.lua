
function main(sel)

	if(NewWorld(53, 1809,3453) == 1) then
	SetFightState(1)		--
	end
end;
