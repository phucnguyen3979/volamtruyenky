
function main(sel)

	NewWorld(121, 2201,4171)		--	
	SetFightState(1)		--

end;
