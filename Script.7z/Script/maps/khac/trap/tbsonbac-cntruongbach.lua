
function main(sel)

	NewWorld(320,1385,2259)		--	
	SetFightState(1)		--
    AddWayPoint(197)

end;
