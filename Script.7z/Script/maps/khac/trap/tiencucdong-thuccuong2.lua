
function main(sel)

	NewWorld(92,1898,3209)		--	
	SetFightState(1)		--
    AddWayPoint(151)
end;
