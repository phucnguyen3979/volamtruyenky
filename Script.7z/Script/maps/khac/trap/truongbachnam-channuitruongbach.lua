
function main(sel)

	NewWorld(320,1390,3159)		--	
	SetFightState(1)		--
    AddWayPoint(197)

end;
