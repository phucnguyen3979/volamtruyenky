
function main(sel)

	NewWorld(53,1339,3307)		--	
	SetFightState(1)		--

end;
