function main(sel)
	
	if (GetMSRestTime(1,1) > 0) then
	SetPos(1251,3537)
	SetFightState(0)
	end
end;
