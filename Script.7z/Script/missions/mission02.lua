
Include("\\script\\library\\worldlibrary.lua");

--co le chi co admin chay ham nay
function PlayerBeginMission()
end;
--co le chi co admin chay ham nay
function PlayerRunMission()
end;
--co le chi co admin chay ham nay
function PlayerEndMission()
end;

--loai bo player ra khoi mission thi se chay ham nay, thoat ra cung la loai bo
function OnLeave(nPlayerIndex)
	--PlayerIndex = nPlayerIndex
	--SubWorld la bien' toan` cau` luu chi so map, phai doi ra mapid
end;
