-- Source Vo Lam Truyen Ky
-- Copyright (C) 2024 Phuc Nguyen.
-- This program comes with NO WARRANTY; see LICENSE.txt for details.
-- You are free to redistribute it under certain conditions.
function main(NpcIndex)
dofile("script\\msg.lua")
msg()
end
------------------######------------------
function msg()

  --AddCountNews2("<color=yellow>Ch�o m�ng <color=red>"..GetName().."<color> tham gia v�o th� gi�i v� l�m truy�n k� .<color>",1)

  Talk(1,"no","Xin ch�o <bclr=blue>"..GetName().."<bclr>! Ch�o m�ng ��i Hi�p tham gia v�o V� L�m Truy�n K�!<color>\nPhi�n B�n: <color=yellow>V� L�m Thi�n Tuy�t<color>\nPh�t Tri�n B�i: <color=green>Ph�c Nguy�n<color>\nScript by:<color=green> Ph�c Nguy�n")

end

function no()

end
