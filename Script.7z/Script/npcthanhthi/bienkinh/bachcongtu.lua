--hoangnkh
function main(sel)
	Talk(1,"",14759);
end