--Phuc Nguyen--
function main(sel)
	Talk(1,"",14754);
end