--hoangnkh
function main(sel)
	Talk(1,"",14765);
end