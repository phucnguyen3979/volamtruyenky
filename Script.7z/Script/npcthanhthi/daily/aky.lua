--Phuc Nguyen--
function main(sel)
	Talk(5,"",13727,13728,13729,13730,13731);
end