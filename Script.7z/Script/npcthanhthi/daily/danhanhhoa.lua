--Phuc Nguyen--
function main(sel)
	Talk(4,"",13762,13763,13764,13765);
end