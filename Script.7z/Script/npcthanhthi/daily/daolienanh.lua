--Phuc Nguyen--
function main(sel)
	Talk(3,"",13766,13767,13768);
end