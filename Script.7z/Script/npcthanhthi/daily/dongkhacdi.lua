--Phuc Nguyen--
function main(sel)
	Talk(1,"",13770);
end