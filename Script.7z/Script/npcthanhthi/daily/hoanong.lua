--Phuc Nguyen--
function main(sel)
	Talk(1,"",random(13828,13830));
end