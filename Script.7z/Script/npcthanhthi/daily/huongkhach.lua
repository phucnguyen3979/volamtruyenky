--Phuc Nguyen--
function main(sel)
	Talk(1,"",random(13856,13857));
end