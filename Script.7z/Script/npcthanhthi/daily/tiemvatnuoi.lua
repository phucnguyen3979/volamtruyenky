--Phuc Nguyen--
function main(sel)
	Talk(3,"",13883,13884,13885);
end