--Phuc Nguyen--
function main(sel)
	Talk(1,"",GetSex()==0 and 13737 or 13738);
end