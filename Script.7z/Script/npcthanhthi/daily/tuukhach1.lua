--Phuc Nguyen--
function main(sel)
	Talk(6,"",13833,13834,13835,13836,13837,13838);
end