--Phuc Nguyen--
function main(sel)
	Say(15372,0);
end