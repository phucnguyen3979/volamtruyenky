--Phuc Nguyen--
function main(sel)
	Talk(3,"",15328,15329,15330);
end