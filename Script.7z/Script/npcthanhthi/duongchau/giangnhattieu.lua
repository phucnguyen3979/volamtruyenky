--Phuc Nguyen--
function main(sel)
	Talk(1,"",random(15413,15414));
end