--Phuc Nguyen--
function main(sel)
	Say(15368,0);
end