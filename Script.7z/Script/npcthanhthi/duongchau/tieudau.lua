--Phuc Nguyen--
function main(sel)
	Talk(1,"",15474);
end