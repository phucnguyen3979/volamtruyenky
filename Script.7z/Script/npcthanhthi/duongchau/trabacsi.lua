--Phuc Nguyen--
function main(sel)
	Talk(1,"",random(15311,15314));
end