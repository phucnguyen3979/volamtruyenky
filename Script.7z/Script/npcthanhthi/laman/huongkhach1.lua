--Phuc Nguyen--
function main(sel)
	Talk(2,"",10751,10752);
end