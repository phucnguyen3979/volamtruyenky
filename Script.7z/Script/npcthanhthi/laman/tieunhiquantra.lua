--Phuc Nguyen--
function main(sel)
	Talk(1,"",10800);
end