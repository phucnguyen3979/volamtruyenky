function main(sel)
	Talk(1,"",12221);
end