function main(sel)
	Say(12183,0);
end