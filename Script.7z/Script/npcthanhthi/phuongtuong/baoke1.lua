function main(sel)
	Talk(1,"",12216);
end