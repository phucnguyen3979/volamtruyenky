function main(sel)
	Talk(1,"",12215);
end