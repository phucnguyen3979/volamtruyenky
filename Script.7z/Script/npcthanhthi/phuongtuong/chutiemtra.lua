--Phuc Nguyen--
function main()
	Talk(1,"",random(12211,12212));
end
