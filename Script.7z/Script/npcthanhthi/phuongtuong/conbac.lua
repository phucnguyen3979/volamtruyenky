--Phuc Nguyen--
function main()
	Talk(1,"",12169);
end
