--Phuc Nguyen--
function main()
	Talk(1,"",12171);
end
