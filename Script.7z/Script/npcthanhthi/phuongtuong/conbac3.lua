--Phuc Nguyen--
function main()
	Talk(1,"",12172);
end
