--Phuc Nguyen--
function main()
	Talk(1,"",12196);
end
