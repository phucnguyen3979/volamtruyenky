function main(sel)
	Talk(1,"",12180);
end