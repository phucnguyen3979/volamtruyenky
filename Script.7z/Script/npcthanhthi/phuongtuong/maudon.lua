function main(sel)
	Talk(1,"",12222);
end