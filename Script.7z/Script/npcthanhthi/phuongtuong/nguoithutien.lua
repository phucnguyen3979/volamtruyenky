function main(sel)
	Talk(1,"",12214);
end