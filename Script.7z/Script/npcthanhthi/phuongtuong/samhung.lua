function main(sel)
	Talk(1,"",12205);
end