function main(sel)
	Talk(4,"",12207,12208,12209,12210);
end