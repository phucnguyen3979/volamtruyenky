function main(sel)
	Talk(1,"",12191);
end