function main(sel)
	Talk(1,"",12166);
end