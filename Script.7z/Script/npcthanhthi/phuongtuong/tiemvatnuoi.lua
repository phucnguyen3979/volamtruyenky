function main(sel)
	Talk(1,"",12213);
end