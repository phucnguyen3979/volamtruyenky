function main(sel)
	Talk(1,"",12168);
end