--Phuc Nguyen--
function main()
	Talk(1,"",random(12218,12220));
end
