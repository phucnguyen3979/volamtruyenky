function main(sel)
	Talk(1,"",random(15249,15251));
end