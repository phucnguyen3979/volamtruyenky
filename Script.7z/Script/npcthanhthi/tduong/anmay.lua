function main(sel)
	Talk(1,"",15235);
end