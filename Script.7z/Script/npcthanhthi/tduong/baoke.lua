function main(sel)
	Talk(1,"",15205);
end