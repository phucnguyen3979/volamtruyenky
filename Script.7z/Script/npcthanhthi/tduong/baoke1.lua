function main(sel)
	Talk(1,"",15208);
end