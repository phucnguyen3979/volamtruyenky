function main(sel)
	Talk(1,"",15210);
end