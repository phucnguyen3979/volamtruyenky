function main(sel)
	Talk(1,"",15247);
end