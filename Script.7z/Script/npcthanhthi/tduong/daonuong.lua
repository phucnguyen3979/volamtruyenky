function main(sel)
	Talk(1,"",15224);
end