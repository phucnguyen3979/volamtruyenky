function main(sel)
	Say(15230,0);
end