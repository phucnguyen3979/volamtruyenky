function main(sel)
	Talk(1,"","Ta l� <npc>");
end