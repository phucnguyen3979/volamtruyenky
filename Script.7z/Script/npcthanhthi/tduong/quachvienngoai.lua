function main(sel)
	Talk(1,"",15236);
end