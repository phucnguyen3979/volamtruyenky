function main(sel)
	Talk(1,"",12571);
end