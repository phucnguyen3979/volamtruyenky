function main(sel)
	Talk(1,"",random(15198,15200));
end