function main(sel)
	Say(15197,0);
end