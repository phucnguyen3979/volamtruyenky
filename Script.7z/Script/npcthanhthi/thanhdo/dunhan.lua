--Phuc Nguyen--
function main(sel)
	Talk(1,"",12461);
end