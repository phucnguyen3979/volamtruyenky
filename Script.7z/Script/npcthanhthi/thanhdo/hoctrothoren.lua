--Phuc Nguyen--
function main(sel)
	Talk(1,"",12598);
end