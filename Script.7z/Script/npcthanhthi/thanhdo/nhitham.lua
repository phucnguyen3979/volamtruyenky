--Phuc Nguyen--
function main(sel)
	Talk(1,"",12501);
end