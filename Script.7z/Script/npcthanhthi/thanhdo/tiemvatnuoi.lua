--Phuc Nguyen--
function main(sel)
	Talk(1,"",15203);
end