--Phuc Nguyen--
function main(sel)
	Talk(1,"",GetSex()==0 and 12472 or 12473);
end