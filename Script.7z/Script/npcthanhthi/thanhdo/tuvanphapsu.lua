--Phuc Nguyen--
function main(sel)
	Talk(5,"",12599,12560,12561,1262,12563);
end