
function main()
	Talk(1,"",13020)
end
