
function main()
	Talk(1,"",12941)
end
