
function main()
	Talk(1,"",12934)
end
