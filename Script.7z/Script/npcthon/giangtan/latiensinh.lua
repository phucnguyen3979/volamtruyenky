
function main()
	Say(12940,2,
	"Nghe m�t �o�n s�ch/nghesach",
	"Kh�ng nghe/no"
	)
end

function nghesach()
	Talk(1,"",10647)
end

function no()
end