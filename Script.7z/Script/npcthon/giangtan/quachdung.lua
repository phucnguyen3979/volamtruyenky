
function main()
	Talk(1,"",12935)
end
