
function main()
	Talk(1,"",12928)
end
