
function main()
	Talk(1,"",12938)
end
