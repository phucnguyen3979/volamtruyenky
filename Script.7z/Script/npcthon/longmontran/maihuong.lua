
function main(NpcIndex)
		Talk(1,"",12040)
end;
