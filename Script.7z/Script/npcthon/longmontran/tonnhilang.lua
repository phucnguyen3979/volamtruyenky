
function main(NpcIndex)
		Talk(1,"",12062)
end;
