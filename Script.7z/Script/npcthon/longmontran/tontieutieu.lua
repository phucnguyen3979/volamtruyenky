
function main(NpcIndex)
		Talk(1,"",12073)
end;
