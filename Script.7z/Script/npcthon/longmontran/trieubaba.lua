
function main(NpcIndex)
		Talk(1,"",10699)
end;
