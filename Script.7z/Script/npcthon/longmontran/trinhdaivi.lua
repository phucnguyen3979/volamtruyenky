
function main(NpcIndex)
		Talk(1,"",12039)
end;
