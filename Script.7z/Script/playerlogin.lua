-- Source Vo Lam Truyen Ky
-- Copyright (C) 2024 Phuc Nguyen.
-- This program comes with NO WARRANTY; see LICENSE.txt for details.
-- You are free to redistribute it under certain conditions.

--Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
--Chia lay so du: (a/b - floor(a/b))*b

	-----------------------------------------------------------

function main()
	Yr,Mth,Dy,Hr,Mn,Se = GetTime();
	local nNam = GetTask(TASK_NAM) ;
	local nThang = GetTask(TASK_THANG)
	local nNgay = GetTask(TASK_NGAY)
	if(nNam ~= Yr or nThang ~= Mth or nNgay ~= Dy) then --reset 1 ngay moi
		SetTask(TASK_NAM,Yr);
		SetTask(TASK_THANG,Mth);
		SetTask(TASK_NGAY,Dy);
		--reset task can thiet tai day
		SetTask(TASK_RESET,0);
		SetTask(TASK_RESET2,0);
		SetTask(TASK_DATCUOC4, 0);
		SetTask(TASK_DATCUOC5, 0);
		SetTask(TASK_DATCUOC6, 0);
	end
	local nAuraT = GetTask(TASK_THOIGIAN4);
	if(nAuraT > 0) then
		local nCurTime = GetTimeMin();
		if(nCurTime - nAuraT > 0) then
		SetTask(TASK_THOIGIAN4, 0);
		SetRankEx(0,1);
		end
	end
	local nTTLTime = GetTask(TASK_TIENTHAOLO)
	if(nTTLTime > 0) then
		AddSkillState(440, 1, nTTLTime);
	end
	nTTLTime = GetTask(TASK_THIENSONBAOLO)
	if(nTTLTime > 0) then
		AddSkillState(441, 1, nTTLTime*1080);
	end
	nTTLTime = GetTask(TASK_QUEHOATUU)
	if(nTTLTime > 0) then
		AddSkillState(450, 1, nTTLTime*1080);
	end
	DelMagic(1486);

	-----------------------------------------------------------
--kiem tra cac ho tro nhan vat
	CheckAdmin() --neu nguoi choi tao account la admin thi se nhan dc lenh bai gm.
	
	CheckTuiMau() --ho tro tui mau
	
	CheckCamNang() --lenh bai tan thu
    
	--Checkmattrang() --neu ban muon ho tro nguoi choi vong sang ho tro
	
--thong bao khi nguoi choi vao game	
	if(GetLevel() < 10) then
	Msg2SubWorld("<color=yellow>Chµo Mõng <color=red>"..GetName().."<color> Tham Gia Vâ L©m TruyÒn Kú .<color>") end
	end

	-----------------------------------------------------------

--khi tao tai khoan ten la "admin" & "admin2" ban se nhan duoc lenh bai GameMaster.	
function CheckAdmin()
if(GetAccount() ~= "admin" and GetAccount() ~= "admin2") then return end
	 if GetTaskTemp(20) == 0 then
	 --SetLevel(90) -- lv 90
     SetRankEx(234); --vong sang co chu Game Master.
     AddMagic(713,1); --Skill GM
	--AddMagic(733,1); --Skill GM
     if(GetItemCount(64,4) < 1) then 
     LenhBai = ItemSetAdd(0,4,64,0,0,5,0,0); -- Lenh Bai GameMaster
     AddItemID(LenhBai);
end
end
end

--tui mau tan thu ,ben trong la cuu hoa ngoc lo hoan.
function CheckTuiMau()
if(GetItemCount(0,5) < 1) then 
     TuiMau = ItemSetAdd(0,5,0,0,0,5,0,0); -- Tui Mau
     AddItemID(TuiMau);
end
end

--lenh bai tan thu ,giup nguoi choi cong diem nhan vat.
function CheckCamNang()
if(GetItemCount(31,5) < 1) then 
     LenhBai = ItemSetAdd(0,5,31,0,0,5,0,0); -- Lenh Bai Tan Thu
     AddItemID(LenhBai);
end
end

--khi nhan vat chet se mat vong sang thoat game vao lai la co.
function Checkmattrang() --Vong sang tren dau nhan vat
	if(GetLevel() > 30) then --ho tro den lv 30
	return end
    AddSkillState( 451, 1 ,388800);--mat trang vang X 1.5 EXP
end	

	-----------------------------------------------------------

function no()

end

--khi ban viet file script ban hay viet comment code lai cho nhung nguoi sau hieu khi ho can chinh sua.
--Nhu vay la hoan tat file Playerlogin.lua ,ban co the them hoac chinh sua theo y ban.
