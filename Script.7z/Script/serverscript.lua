--Phuc Nguyen--
Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\startgame\\khoitaoserver.lua");

function StartGame()
    release_congthanh()
	khoidongtoanserver()
	print("KHOI TAO MAY CHU THANH CONG")	
end
