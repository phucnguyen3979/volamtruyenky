-- Source Vo Lam Truyen Ky
-- Copyright (C) 2024 Phuc Nguyen.
-- This program comes with NO WARRANTY; see LICENSE.txt for details.
-- You are free to redistribute it under certain conditions.
Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\time.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\npcfile.lua");
Include("\\script\\header\\bosstieuhk.lua");
Include("\\script\\header\\huyhoang.lua");
Include("\\script\\header\\vuotai.lua");

function main(NpcIndex)
dofile("script\\servertimer.lua") --tu dong reload , thoat game vao lai la duoc.
thongbao()
end

MSG_LIENDAU = "<color=green>V� l�m ki�t xu�t %d �� ��n giai �o�n b�o danh. C�c cao th� mau nhanh ch�n ��ng k� thi ��u!"
--Chia lay so du: (a/b - floor(a/b))*b

Yr,Mth,Dy,Hr,Mn,Se = 0,0,0,0,0,0;

function OnServerTimer()
	Yr,Mth,Dy,Hr,Mn,Se = GetTime()
		 
		 thongbao()
		 
	     resettask()

	     addbosstieuhk()

	     addhuyhoang()

	     active_vuotai()

	     active_tongkim()

		 active_phonglangdo()

	     active_liendau()

         active_dautruong()
		 
		 active_congthanh()
		 
		 addfullnpc()

end

------------------######------------------

function thongbao() -- Chay thong bao toan Server chay ngau nhien.
	if (Mn == 0) or (Mn == 10) or (Mn == 20) or (Mn == 30) or (Mn == 40) or (Mn == 50) then
		AddNews2(MSG[random(getn(MSG))]) --chay ngau nhien
	end
end

MSG = {
        "Save r��ng th�nh th� AutoIngame, ho�t ��ng chu�n nh�t!",
	    "H��ng d�n T�n th�: ��i Hi�p c� th� luy�n Skill 120 v� 150 t�i Maps luy�n Skill h�y t�m NPC ��o Nh�n Qu� v� s� d�ng Khi�u Chi�n L�nh �� ���c ��n ��.",
        "Nghi�m c�m h�nh vi gian l�n �i�m trong T�ng Kim, vi ph�m s� b� x� l� nghi�m.",
        "�� tr�nh b� lo�ng, spam k�nh th�nh th� ngo�i vi�c mua b�n s� b� kh�a chat t�m th�i. Ti�p t�c t�i ph�m s� b� kh�a chat 1 ng�y.",
        "Nghi�m c�m d�ng autospam �� l�ng m�, x�c ph�m ng��i ch�i kh�c ho�c BQT. Vi ph�m s� b� c�m chat, t�i ph�m s� b� kh�a t�i kho�n.",
        "Ch�o m�ng b�n tham gia v�o th� gi�i V� L�m, game ���c edit b�i Ph�c Nguy�n",
        "Ch�c c�c b�n c� nh�ng gi�y ph�t b�n t�u giang h� vui v�!"
}
------------------######------------------

function resettask()
	if(Hr ~= 0 or Mn ~= 0) then
	return end
	SetDataInt(DATA_DCHAVERES,0);
	local nValue = 0;
	for i=1,1499 do
		PlayerIndex = i;
		if(GetPlayerNpcIdx() > 0) then
		SetTask(TASK_NAM,Yr-2000);
		SetTask(TASK_THANG,Mth);
		SetTask(TASK_NGAY,Dy);
		--reset task ngay moi
		SetTask(TASK_RESET,0);
		SetTask(TASK_RESET2,0);
		SetTask(TASK_DATCUOC4, 0);
		SetTask(TASK_DATCUOC5, 0);
		SetTask(TASK_DATCUOC6, 0);
		end
	end
end

------------------######------------------

TIME_TOCHANGE = 32400 --Sau 30p NPC se mat

function addfullnpc() --NPC than tai o Tuong Duong
         gio = tonumber(date("%H"))
         phut = tonumber(date("%M"))
         giay = tonumber(date("%S"))
     if gio  == 16 and phut <= 15  then --thoi gian 

	nNpcIdx = AddNpcNew(1528,1,78,1566*32,3241*32,"\\script\\global\\npcchucnang\\thantai.lua",6,"Th�n T�i")
	SetNpcLifeTime(nNpcIdx, TIME_TOCHANGE);
	
     end
end

------------------######------------------

function active_somayman()
	if(Hr == 16 and Mn == 45) then
		SetDataInt(DATA_DCHAVERES,1);
		SetDataInt(DATA_DATCUOC,GetDataInt(DATA_DATCUOC)+1);
		for i=DATA_DCBEGIN,DATA_DCEND do
		SetDataInt(i,random(99));
		end
		Msg2SubWorld("<color=yellow>Hi�n t�i �� c� k�t qu� 'con s� may m�n'. Qu� ��ng ��o xem � L� quan.");
	end
end

------------------######------------------

function addbosstieuhk() 
    if (Hr == 01 and Mn == 15) then
	releasebosstieu()
	return end
    if (Hr == 03 and Mn == 15 )then
	releasebosstieu()
	return end
    if (Hr == 06 and Mn == 15) then
	releasebosstieu()
	return end
    if (Hr == 09 and Mn == 15 )then
	releasebosstieu()
	return end
    if (Hr == 12 and Mn == 15) then
	releasebosstieu()
	return end
    if (Hr == 15 and Mn == 15 )then
	releasebosstieu()
	return end
    if (Hr == 17 and Mn == 15) then
	releasebosstieu()
	return end
    if (Hr == 19 and Mn == 15 )then
	releasebosstieu()
	return end
    if (Hr == 21 and Mn == 15) then
	releasebosstieu()
	return end
    if (Hr == 23 and Mn == 15 )then
	releasebosstieu()
	return end
end;

------------------######------------------

function addhuyhoang()
--qua huy hoang
	if(Hr == 02 and Mn == 0) then
	releasehhh()
	return end
	if(Hr == 04 and Mn == 0) then
	releaseqhh()
	return end
	if(Hr == 06 and Mn == 0) then
	releasehhh()
	return end
	if(Hr == 08 and Mn == 0) then
	releaseqhh()
	return end
	if(Hr == 10 and Mn == 0) then
	releaseqhh()
	return end
	if(Hr == 12 and Mn == 0) then
	releaseqhh()
	return end
	if(Hr == 14 and Mn == 0) then
	releaseqhh()
	return end
	if(Hr == 16 and Mn == 0) then
	releaseqhh()
	return end
	if(Hr == 18 and Mn == 0) then
	releaseqhh()
	return end
	if(Hr == 20 and Mn == 0) then
	releaseqhh()
	return end
	if(Hr == 22 and Mn == 0) then
	releaseqhh()
	return end
	if(Hr == 00 and Mn == 0) then
	releaseqhh()
	return end
--qua hoang kim

	if(Hr == 01 and Mn == 0) then
	releasehhk()
	return end
	if(Hr == 03 and Mn == 5) then
	releaseqhk()
	return end
	if(Hr == 05 and Mn == 0) then
	releasehhk()
	return end
	if(Hr == 07 and Mn == 0) then
	releasehhk()
	return end
	if(Hr == 09 and Mn == 0) then
	releasehhk()
	return end
	if(Hr == 11 and Mn == 0) then
	releasehhk()
	return end
	if(Hr == 13 and Mn == 0) then
	releasehhk()
	return end
	if(Hr == 15 and Mn == 0) then
	releasehhk()
	return end
	if(Hr == 17 and Mn == 0) then
	releasehhk()
	return end
	if(Hr == 19 and Mn == 0) then
	releasehhk()
	return end
	if(Hr == 21 and Mn == 0) then
	releasehhk()
	return end
	if(Hr == 23 and Mn == 0) then
	releasehhk()
	return end
end;

------------------######------------------

function active_vuotai()
	for i=1,getn(VUOTAI_TIMER) do
		if(Hr == VUOTAI_TIMER[i][1] and Mn == VUOTAI_TIMER[i][2]) then
			AddCountNews(10221,3)
			local nSubWorldId;
			for i=1,getn(MAP_VUOTAI) do
				nSubWorldId = SubWorldID2Idx(MAP_VUOTAI[i])
				if (nSubWorldId >= 0) then
				SubWorld = nSubWorldId;
				OpenMission(1)
				StartMissionTimer(1,1, 5400)--so phut de chinh thuc bat dau
				end
			end
		end
	end
	--thong bao bat dau
	if(Mn == 5) then
		AddCountNews(10247,3)
	end
end

------------------######------------------

function active_phonglangdo()
	for i=1,getn(PHONGLANGDO_TIMER) do
		if(Hr == PHONGLANGDO_TIMER[i][1] and Mn == PHONGLANGDO_TIMER[i][2]) then
			AddCountNews(10137,3)
			local nSubWorldId;
			nSubWorldId = SubWorldID2Idx(337)
			if (nSubWorldId >= 0) then
			SubWorld = nSubWorldId;
			OpenMission(1)
			StartMissionTimer(1,1, 9720)--so phut de chinh thuc bat dau
			end
		end
	end
end

function active_dautruong()
	if(Hr == 22 and Mn == 1) then
		local nSubWorldId = SubWorldID2Idx(964)
		if (nSubWorldId >= 0) then
			SubWorld = nSubWorldId;
			if(IsMission(1) == 1) then
			CloseMission(1)
			end
			for i=0,9 do
				SetMissionV(i,0);
			end
			OpenMission(1)
			StartMissionTimer(1,1, 10*1080)--so phut bao danh
			Msg2SubWorld("��u tr��ng lo�n chi�n b�t ��u b�o danh")
			AddNews2("��u tr��ng lo�n chi�n b�t ��u b�o danh. Th�i gian b�o danh c�n l�i l� 10 ph�t!")
		end
	end
end

function active_liendau()
	if Dy < 25 then
		if (Hr == 18) then
			if(Mn == 0 or Mn == 15 or Mn == 30 or Mn == 45) then
				Msg2SubWorld(format(MSG_LIENDAU,floor(Mn/15)+1))
				local nSubWorldId = SubWorldID2Idx(396)
				if (nSubWorldId >= 0) then
				SubWorld = nSubWorldId;
				OpenMission(1)
				StartMissionTimer(1,1, 5400)--so phut de chinh thuc bat dau
				-- logHoatDong("LD Run OKE!")
				end
			elseif (Hr == 19) and (Mn == 2) then
				SaveDataFile();
			end
		elseif (Hr == 19) and (Mn == 3) then
		ArrangeData(); 
		end
	end
end

function active_tongkim()
	local nSubWorldId = SubWorldID2Idx(380)
	if (nSubWorldId >= 0) then
	for i=1,getn(TONGKIM_TIMER) do
		if(Hr == TONGKIM_TIMER[i][1] and Mn == TONGKIM_TIMER[i][2]) then
			AddCountNews(10644,3)
			AddCountNews2(10222,3)
			SubWorld = nSubWorldId;
			OpenMission(1)
			StartMissionTimer(1,1, 5*1080)--so phut de chinh thuc bat dau
			StartMissionTimer(1,2, 15*1080)--thoi gian nguyen soai ra
			StartMissionTimer(1,3, 30*1080)--tong thoi gian ca tran
		end
	end
	--thoi gian bao danh con lai
	SubWorld = nSubWorldId;
	local RestTK = GetMSRestTime(1,1);
	local Minute;
	if (RestTK > 0) then
		Minute = floor(RestTK/1080);
		if(Minute == 7 or Minute == 3) then
		AddCountNews(10644,3)
		AddCountNews2(format("Th�i gian b�o danh T�ng Kim c�n l�i l� %d ph�t.",Minute),3)
		end
	end
	--thoi gian con lai cua tran danh'
	RestTK = GetMSRestTime(1,3);
	if (RestTK > 0) then
		Minute = floor(RestTK/1080);
		if(Minute > 0) then
		for i=1,GetMSPlayerCount(1) do
			if((GetPMParam(1, i, 0) == 1) and (GetPMParam(1, i, 1) == 1)) then --neu co online va dang trong chien dau
				PlayerIndex = MSDIdx2PIdx(1, i);
				SendReport(1,Minute,0);
			end
		end
		end
	end
	
	end
end;

------------------######------------------

function active_congthanh()
	--Check thoi gian
	local nSubWorldId = SubWorldID2Idx(221)
	if (nSubWorldId >= 0) then
	if Mn == 55 then -- thay ��i s� n�y theo th�i gian c�a m�y t�nh th�m 5 ph�t �� c� th�i gian ch�y sever v� ��ng nh�p game
			AddCountNews(10645,3)
			AddCountNews2(10223,3)
			SubWorld = nSubWorldId;
			OpenMission(1)
			StartMissionTimer(1,1, 5*1080)--so phut de chinh thuc bat dau
			StartMissionTimer(1,2, 15*1080)--thoi gian nguyen soai ra
			StartMissionTimer(1,3, 30*1080)--tong thoi gian ca tran
	end
	--thoi gian bao danh con lai
	SubWorld = nSubWorldId;
	local RestTK = GetMSRestTime(1,1);
	local Minute;
	if (RestTK > 0) then
		Minute = floor(RestTK/1080);
		if(Minute == 7 or Minute == 3) then
		AddCountNews(10644,3)
		AddCountNews2(format("Th�i gian b�o danh C�ng Th�nh c�n l�i l� %d ph�t.",Minute),3)
		end
	end
	--thoi gian con lai cua tran danh'
	RestTK = GetMSRestTime(1,3);
	if (RestTK > 0) then
		Minute = floor(RestTK/1080);
		if(Minute > 0) then
		for i=1,GetMSPlayerCount(1) do
			if((GetPMParam(1, i, 0) == 1) and (GetPMParam(1, i, 1) == 1)) then --neu co online va dang trong chien dau
				PlayerIndex = MSDIdx2PIdx(1, i);
				SendReport(1,Minute,0);
			end
		end
		end
	end
	
	end
end;

------------------######------------------
