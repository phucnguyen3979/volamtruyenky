-- Source Vo Lam Truyen Ky
-- Copyright (C) 2024 Phuc Nguyen.
-- This program comes with NO WARRANTY; see LICENSE.txt for details.
-- You are free to redistribute it under certain conditions.

function addnpclongtuyen()
	local nNpcIdx;
	--Huu dom, heo trang kim mieu 42,43

	----NPC Mon Phai trong thon-----
	--AddNpcNew(189,1,174,1592*32,3129*32,"\\script\\npcthon\\npcmonphai\\thieulam.lua",6,183)
	--AddNpcNew(184,1,174,1610*32,3196*32,"\\script\\npcthon\\npcmonphai\\thienvuong.lua",6,247)
	--AddNpcNew(186,1,174,1621*32,3205*32,"\\script\\npcthon\\npcmonphai\\ngudoc.lua",6,178)
	--AddNpcNew(177,1,174,1613*32,3174*32,"\\script\\npcthon\\npcmonphai\\duongmon.lua",6,246)
	--AddNpcNew(83 ,1,174,1636*32,3184*32,"\\script\\npcthon\\npcmonphai\\ngami.lua",6,248)
	--AddNpcNew(171,1,174,1581*32,3203*32,"\\script\\npcthon\\npcmonphai\\thuyyen.lua",6,177)	
	--AddNpcNew(103,1,174,1601*32,3124*32,"\\script\\npcthon\\npcmonphai\\caibang.lua",6,194)
	--AddNpcNew(181,1,174,1619*32,3163*32,"\\script\\npcthon\\npcmonphai\\thiennhan.lua",6,240)	
	--AddNpcNew(188,1,174,1635*32,3189*32,"\\script\\npcthon\\npcmonphai\\vodang.lua",6,249)
	--AddNpcNew(309,1,174,1576*32,3145*32,"\\script\\npcthon\\npcmonphai\\conlon.lua",6,181)

	----NPC Chuc nang-----
	nNpcIdx = AddNpcNew(625,1,174,1620*32,3188*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 19);
	nNpcIdx = AddNpcNew(219,1,174,1566*32,3202*32,"\\script\\global\\npcchucnang\\taphoa.lua",6,84); SetNpcValue(nNpcIdx, 23);
	nNpcIdx = AddNpcNew(198,1,174,1607*32,3253*32,"\\script\\global\\npcchucnang\\thoren.lua",6,55); SetNpcValue(nNpcIdx, 22);
	nNpcIdx = AddNpcNew(203,1,174,1572*32,3256*32,"\\script\\global\\npcchucnang\\hieuthuoc.lua",6,251); SetNpcValue(nNpcIdx, 24);
	AddNpcNew(239,1,174,1637*32,3196*32,"\\script\\global\\npcchucnang\\xaphu.lua",6,42)
	AddNpcNew(108,1,174,1608*32,3200*32,"\\script\\global\\npcchucnang\\datau.lua",6,59)
	AddNpcNew(377,1,174,1630*32,3219*32, "\\script\\global\\npcchucnang\\lequan.lua",6,57) 
	AddNpcNew(663,1,174,1692*32,3293*32,"\\script\\global\\npcchucnang\\longngu.lua",6)--enemy199
	AddNpcNew(373,1,174,1654*32,3205*32,"\\script\\global\\npcchucnang\\cthanhquan.lua",6,186)
	AddNpcNew(311,1,174,1584*32,3460*32,"\\script\\global\\npcchucnang\\vosu.lua",6,201)
	--AddNpcNew(87,1,174,1601*32,3188*32,"\\script\\global\\npcchucnang\\trogiup.lua",6,"T©n Thñ Sø Gi¶ ") --308
end

function addtraplongtuyen()

end

function addobjlongtuyen()
	
end
