-- Source Vo Lam Truyen Ky
-- Copyright (C) 2024 Phuc Nguyen.
-- This program comes with NO WARRANTY; see LICENSE.txt for details.
-- You are free to redistribute it under certain conditions. 
function release_congthanh()

	local nNpcIdx;
                                --===============CONG THANH CHIEN TAM TRU===============--
	----NPC Chuc nang phe Cong-----
	nNpcIdx = AddNpcNew(625,1,325,1561*32,3194*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 1);
	nNpcIdx = AddNpcNew(235,11,221,1894*32,3603*32,"\\script\\feature\\congthanh\\xaphuct.lua",6,42);SetNpcValue(nNpcIdx, 1);
	nNpcIdx = AddNpcNew(203,1,221,1925*32,3576*32,"\\script\\feature\\congthanh\\quanduoc.lua",6,614); SetNpcValue(nNpcIdx, 96);
	nNpcIdx = AddNpcNew(203,1,221,1916*32,3567*32,"\\script\\feature\\congthanh\\quanduoc.lua",6,614); SetNpcValue(nNpcIdx, 96);	
	nNpcIdx = AddNpcNew(55,1,221,1876*32,3566*32,"\\script\\feature\\congthanh\\dacthamcong.lua",6,"C�ng Th�nh Ti�n Qu�n ��c Th�m");SetNpcValue(nNpcIdx, 1);
	nNpcIdx = AddNpcNew(625,1,380,39541,113302,"\\script\\global\\npcchucnang\\ruongchua.lua",6);

	----NPC Chuc nang phe Thu-----
	nNpcIdx = AddNpcNew(625,1,325,1593*32,3094*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 2);
	nNpcIdx = AddNpcNew(235,1,221,1537*32,3204*32,"\\script\\feature\\congthanh\\xaphuct.lua",6,823);
	nNpcIdx = AddNpcNew(203,1,221,1557*32,3225*32,"\\script\\feature\\congthanh\\quanduoc.lua",6,613); SetNpcValue(nNpcIdx, 96);
	nNpcIdx = AddNpcNew(203,1,221,1547*32,3214*32,"\\script\\feature\\congthanh\\quanduoc.lua",6,614); SetNpcValue(nNpcIdx, 96);
	nNpcIdx = AddNpcNew(49,1,221,1566*32,3235*32,"\\script\\feature\\congthanh\\dacthamthu.lua",6,"Th� Th�nh Ti�n Qu�n ��c Th�m");
	nNpcIdx = AddNpcNew(625,1,380,54501,97854,"\\script\\global\\npcchucnang\\ruongchua.lua",6);

--------PHE THU THANH

    nNpcIdx = AddNpcNew(530,100,221,1590*32,3412*32,"\\script\\global\\lastdamage\\death_longtru.lua",
	5,"Long Tr�",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(530,100,221,1655*32,3347*32,"\\script\\global\\lastdamage\\death_longtru.lua",
	5,"Long Tr�",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(530,100,221,1723*32,3281*32,"\\script\\global\\lastdamage\\death_longtru.lua",
	5,"Long Tr�",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(532,100,221,1728*32,3410*32,"\\script\\global\\lastdamage\\death_longtru.lua",
    5,"C�ng Th�nh M�n",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(532,100,221,1795*32,3342*32,"\\script\\global\\lastdamage\\death_longtru.lua",
	5,"C�ng Th�nh M�n",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(532,100,221,1662*32,3474*32,"\\script\\global\\lastdamage\\death_longtru.lua",
	5,"C�ng Th�nh M�n",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(2064,100,221,1657*32,3354*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Nguy�n So�i",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1734*32,3281*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Th�nh T��ng Qu�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1724*32,3291*32,"\\script\\global\\lastdamage\\death_phethu.lua",
    5,"Th� Th�nh Nguy�n So�i",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1723*32,3270*32,"\\script\\global\\lastdamage\\death_phethu.lua",
    5,"Th� Th�nh Th�ng L�nh",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1713*32,3280*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Th�nh Binh T��ng",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1666*32,3347*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Th�nh T��ng Qu�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1656*32,3357*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Th�nh Nguy�n So�i",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1655*32,3336*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Th�nh Th�ng L�nh",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1645*32,3346*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Th�nh Binh T��ng",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1590*32,3400*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Th�nh T��ng Qu�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1580*32,3410*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Th�nh Nguy�n So�i",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1602*32,3412*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Th�nh Th�ng L�nh",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1592*32,3422*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Th�nh Binh T��ng",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1657*32,3355*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1657*32,3358*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1657*32,3352*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1777*32,3302*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1767*32,3312*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1757*32,3322*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1747*32,3332*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1737*32,3342*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1727*32,3352*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1717*32,3362*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1707*32,3372*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1697*32,3382*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1687*32,3392*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1677*32,3402*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1667*32,3412*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1657*32,3422*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1647*32,3432*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1637*32,3442*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1700*32,3247*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1690*32,3257*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1680*32,3267*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1670*32,3277*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1660*32,3287*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1650*32,3297*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1640*32,3307*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1630*32,3317*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1620*32,3327*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1610*32,3392*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1600*32,3337*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1590*32,3347*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1580*32,3357*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1570*32,3367*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
    nNpcIdx = AddNpcNew(1786,100,221,1560*32,3377*32,"\\script\\global\\lastdamage\\death_phethu.lua",
	5,"Th� Binh Th�nh M�n",1,"555",50000,5000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\feature\\congthanh\\drop_congthanh.lua");
 
--------PHE CONG THANH
 --1337 cong thanh chien xa
    nNpcIdx = AddNpcNew(2064,100,221,1766*32,3448*32,"\\script\\global\\lastdamage\\death_phecong.lua",
	5,"T��ng Qu�n",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(1903,100,221,1765*32,3447*32,"\\script\\global\\lastdamage\\death_phecong.lua",
	5,"C�ng Th�nh Xung Xa",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(1903,100,221,1764*32,3443*32,"\\script\\global\\lastdamage\\death_phecong.lua",
	5,"C�ng Th�nh Xung Xa",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(1786,100,221,1766*32,3445*32,"\\script\\global\\lastdamage\\death_phecong.lua",
	5,"Qu�n C�ng Th�nh",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(1786,100,221,1770*32,3455*32,"\\script\\global\\lastdamage\\death_phecong.lua",
	5,"Qu�n C�ng Th�nh",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(1786,100,221,1771*32,3453*32,"\\script\\global\\lastdamage\\death_phecong.lua",
	5,"Qu�n C�ng Th�nh",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(1786,100,221,1776*32,3445*32,"\\script\\global\\lastdamage\\death_phecong.lua",
	5,"Qu�n C�ng Th�nh",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(1786,100,221,1777*32,3455*32,"\\script\\global\\lastdamage\\death_phecong.lua",
	5,"Qu�n C�ng Th�nh",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(1786,100,221,1775*32,3453*32,"\\script\\global\\lastdamage\\death_phecong.lua",
	5,"Qu�n C�ng Th�nh",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(1786,100,221,1737*32,3418*32,"\\script\\global\\lastdamage\\death_phecong.lua",
	5,"Qu�n C�ng Th�nh",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);
    nNpcIdx = AddNpcNew(1786,100,221,1734*32,3417*32,"\\script\\global\\lastdamage\\death_phecong.lua",
	5,"Qu�n C�ng Th�nh",1,"555",50000,50000000,10000,10000,nil,nil,nil,nil,nil,80,2,nil);

end;

function trapcongthanh()

	AddTrapEx1(221,1583,3220,12,"\\script\\maps\\congthanh\\trap\\cong10h.lua")
	AddTrapEx1(221,1590,3264,18,"\\script\\maps\\congthanh\\trap\\cong10h1.lua")
	AddTrapEx1(221,1575,3279,18,"\\script\\maps\\congthanh\\trap\\cong10h2.lua")
	AddTrapEx1(221,1538,3274,18,"\\script\\maps\\congthanh\\trap\\cong10h3.lua")

	AddTrapEx1(221,1905,3549,16,"\\script\\maps\\congthanh\\trap\\cong4h.lua")
	AddTrapEx1(221,1863,3534,18,"\\script\\maps\\congthanh\\trap\\cong4h1.lua")
	AddTrapEx1(221,1849,3549,18,"\\script\\maps\\congthanh\\trap\\cong4h2.lua")
	AddTrapEx1(221,1861,3594,16,"\\script\\maps\\congthanh\\trap\\cong4h3.lua")
end;
