-- Source Vo Lam Truyen Ky
-- Copyright (C) 2024 Phuc Nguyen.
-- This program comes with NO WARRANTY; see LICENSE.txt for details.
-- You are free to redistribute it under certain conditions.
--file nay khi chay la tu reload.

Include("\\script\\header\\monphaiheader.lua");
Include("\\script\\global\\npcchucnang\\phantang.lua");
Include("\\script\\header\\skill150.lua");
Include("\\script\\item\\\\tools\\tool0059.lua");
Include("\\script\\startgame\\khoitaoserver.lua");
Include("\\script\\header\\trungsinh.lua");

-----------------------------------------------------------------------------------------------------------------------

function system ()
Say("Xin ch�o! <color=wood>"..GetName().."<color>! D�y l� h� th�ng qu�n l� m�y ch� <color=red>V� L�m Thi�n Tuy�t<color>.\nHi�n �ang c�:<color=yellow> [ "..GetPlayerCount().." ] <color>ng��i ch�i �ang Online!\nM�i ��i Hi�p ch�n ch�c n�ng d�nh cho Game Master. ",24,

	"K�t th�c ��i tho�i/no")
end

function no()
end;

