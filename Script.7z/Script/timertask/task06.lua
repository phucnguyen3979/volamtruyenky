-- Source Vo Lam Truyen Ky
-- Copyright (C) 2024 Phuc Nguyen.
-- This program comes with NO WARRANTY; see LICENSE.txt for details.
-- You are free to redistribute it under certain conditions.
function OnTimer()
	StopTimer();
end;

function OnMissionTimer(nIndex)
	StopMissionTimer(nIndex,6);
end;